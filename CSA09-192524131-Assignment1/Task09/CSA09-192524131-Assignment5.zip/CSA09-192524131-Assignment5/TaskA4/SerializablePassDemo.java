public class SerializablePassDemo { public static void main(String[] args) { System.out.println("serialVersionUID and transient modifier prevent security gadget chains."); } }
