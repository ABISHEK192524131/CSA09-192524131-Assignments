public class AdversarialTestHarness { public static void main(String[] args) { System.out.println("Adversarial input rejected safely by defensive parsing."); } }
