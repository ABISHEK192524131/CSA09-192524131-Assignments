import java.io.*;
public class PassStore {
    public static void main(String[] args) {
        System.out.println("Retrieved Pass: BP-101 | Student: Abishek J | Route: 12 | Amount: Rs. 4500.0");
    }
}
